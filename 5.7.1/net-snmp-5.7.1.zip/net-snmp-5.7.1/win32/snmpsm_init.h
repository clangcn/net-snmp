init_usm();
