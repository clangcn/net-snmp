shutdown_usm();
